#ifndef SILO_DEFINE_HEAD
#define SILO_DEFINE_HEAD

// default processing size
#define SILO_WORD int
typedef unsigned SILO_WORD DEFAULTWORD;
typedef DEFAULTWORD SIGNALSIZE;
typedef DEFAULTWORD NODEID;
typedef DEFAULTWORD PORTID;
typedef enum logic {false = 0, true = 1} bool;

#define BASICMEM 4096 // 4KiB = 1Page

typedef union unisign {
	SILO_WORD uint;
	DEFAULTWORD sint;
} UNISIGN;

#endif
