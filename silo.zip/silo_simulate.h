#ifndef SILO_SIMULATE_HEAD
#define SILO_SIMULATE_HEAD

#include "silo_define.h"

int SimuInit(void);
int Simulate(void);

#endif
