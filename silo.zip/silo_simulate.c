#ifndef SILO_SIMULATE_CODE
#define SILO_SIMULATE_CODE

#include "silo_define.h"
#include "silo_node.h"
#include "silo_simulate.h"

static NODE ** NextExecList;

int SimuInit(void) {
	// NextExecList = (NODE**)malloc(sizeof(NODE**)*NodeGetNumber());
	
}

int Simulate(void) {
	unsigned int current;
	unsigned int number;
	
	current = 0;
	// number = NodeGetNumber();
	
	while (current < number) {
		
	}
}

#endif
