#ifndef SILO_NODEID_HEAD
#define SILO_NODEID_HEAD

#include "silo_define.h"


int RecyInit();
int RecyStatus(void);
int RecyAbleID();

void   RecyPush(NODEID nodeid);
NODEID RecyPull(void);

void RecySetgcOfs(NODEID nodeid);
void RecyStartgc(NODEID nodeid);



#endif
