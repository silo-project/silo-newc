#include <stdio.h>
#include <stdlib.h>

#include "silo_define.h"

int main(void) {
	int num, i;
	
	RecyInit();
	NodeInit();
	
	for (i = 0; i < 5; i++) {
		num = NodeTest();
		printf("NodeID : %d\n", num);
	}
	
	return 0;
}

