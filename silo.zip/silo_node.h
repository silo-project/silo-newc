/*
	Name: silo node header
	Copyright: SILO
	Author: rumium
	Date: 04-10-20 18:17
	Description: define node-structure, send-form
*/
#ifndef SILO_NODE_HEAD
#define SILO_NODE_HEAD

#include "silo_define.h"
#include "silo_signal.h"


typedef struct node NODE;
typedef struct sendform SENDFORM;

typedef struct node {
	void (*function)(NODE*);
	unsigned int * attribute;
	SIGNAL       * input;
	VALUE        * storage;
	SENDFORM     * output;
} NODE;

typedef struct sendform {
	NODEID nodeid;
	PORTID portid;
} SENDFORM;

// variables





// functions
int NodeInit();
int NodeTest();

NODEID NodeCreate();
void NodeAddPtr(NODE * node, NODEID nodeid);
void NodeDelete(NODEID);
NODEID NodeGetID();

void NodeSetMemory(NODE * node, int long size);

void NodeSetType(NODEID nodeid, void (*function)(NODE*));
void NodeSetAttribute(NODEID nodeid, unsigned int * attr);
void NodeSetOutput(NODEID nodeid, int index, SENDFORM dest);

NODEID NodeGetNumber();
NODE * NodeGetPtr(NODEID nodeid);



#endif
